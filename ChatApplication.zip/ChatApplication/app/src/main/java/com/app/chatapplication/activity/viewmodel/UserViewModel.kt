package com.app.chatapplication.activity.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.app.chatapplication.activity.db.UserDb
import com.app.chatapplication.activity.db.UserEntity

class UserViewModel(app:Application):AndroidViewModel(app) {
    private val userList = MutableLiveData<List<UserEntity>>()

    init {
        getUserData()
    }

    fun getObserverData():MutableLiveData<List<UserEntity>>{
        return userList
    }

    private fun getUserData() {
        val userDao =UserDb.getUserDb(getApplication())?.userDao()
        val list  = userDao?.getAllData()
        userList.value = list
    }

    fun getInsertedData(entity: UserEntity){
        val userDao = UserDb.getUserDb(getApplication())?.userDao()
        userDao?.insertSearchedHistory(entity)
        getUserData()
    }

}