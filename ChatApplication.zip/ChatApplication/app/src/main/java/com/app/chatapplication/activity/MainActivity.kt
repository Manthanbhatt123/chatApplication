package com.app.chatapplication.activity

import android.icu.lang.UCharacter.VerticalOrientation
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.chatapplication.R
import com.app.chatapplication.activity.adapter.ChatAdapter
import com.app.chatapplication.activity.db.UserEntity
import com.app.chatapplication.activity.viewmodel.UserViewModel
import com.app.chatapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ChatAdapter
    private lateinit var viewModel: UserViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        init()
    }

    private fun init(){
        initAdapter()
        initViewModel()
        onClick()
    }

    private fun initAdapter(){
        binding.rvChatMessage.layoutManager = LinearLayoutManager(this ,RecyclerView.VERTICAL,true)
        adapter = ChatAdapter(this)
        binding.rvChatMessage.adapter = adapter
    }

    private fun initViewModel(){
        viewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        viewModel.getObserverData().observe(this){
            adapter.setUserdata(it)
            adapter.notifyDataSetChanged()
        }
    }

    private fun onClick(){
        binding.btnUser1.setOnClickListener {
            val mess = binding.edtMessage.text.toString()
            val entity = UserEntity(0,mess , "")
            viewModel.getInsertedData(entity)
        }

        binding.btnUser2.setOnClickListener {
            val mess = binding.edtMessage.text.toString()
            val entity = UserEntity(0,"" ,mess)
            viewModel.getInsertedData(entity)
        }
    }
}