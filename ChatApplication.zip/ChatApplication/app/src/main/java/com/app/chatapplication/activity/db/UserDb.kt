package com.app.chatapplication.activity.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [UserEntity::class], version = 1, exportSchema = false)
abstract class UserDb:RoomDatabase() {
    abstract fun userDao():UserDao

    companion object{
        private var Instance :UserDb?=null

        fun getUserDb(context: Context):UserDb?{
            if (Instance == null){
                Instance = Room.databaseBuilder(context,UserDb::class.java , "UserDatabase")
                    .allowMainThreadQueries()
                    .build()
            }
            return  Instance
        }
    }
}