package com.app.chatapplication.activity.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ChatUser")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "ID")val id:Int=0,
    @ColumnInfo(name = "User1") val User1:String,
    @ColumnInfo(name = "User2") val User2:String
)
