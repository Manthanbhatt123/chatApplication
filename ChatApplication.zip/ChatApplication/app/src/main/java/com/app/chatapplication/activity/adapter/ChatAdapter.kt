package com.app.chatapplication.activity.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.chatapplication.activity.db.UserEntity
import com.app.chatapplication.databinding.ItemrowChatBinding

class ChatAdapter(private val context: Context):RecyclerView.Adapter<ChatAdapter.MyViewHolder>() {

    private var userList = mutableListOf<UserEntity>()

    fun setUserdata(data:List<UserEntity>){
        this.userList =data.toMutableList()
        notifyDataSetChanged()
    }

    class MyViewHolder (val binding: ItemrowChatBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemrowChatBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val userdata = userList[position]
        if(userdata.User1 !=""){
            holder.binding.userOne.text = userdata.User1
            holder.binding.userOne.visibility = View.VISIBLE
            holder.binding.userTwo.visibility = View.GONE
        }
        if (userdata.User2!= ""){
            holder.binding.userTwo.text = userdata.User2
            holder.binding.userTwo.visibility = View.VISIBLE
            holder.binding.userOne.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return userList.size
    }
}